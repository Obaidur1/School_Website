from django import template

register = template.Library()

@register.filter
def mod(value):
    return value%3